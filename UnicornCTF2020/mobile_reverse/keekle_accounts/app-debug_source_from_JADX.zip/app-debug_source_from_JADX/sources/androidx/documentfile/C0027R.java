package androidx.documentfile;

/* renamed from: androidx.documentfile.R */
public final class C0027R {
    private C0027R() {
    }
}
