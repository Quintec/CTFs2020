package androidx.interpolator;

/* renamed from: androidx.interpolator.R */
public final class C0034R {
    private C0034R() {
    }
}
