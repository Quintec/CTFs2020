package androidx.lifecycle;

/* renamed from: androidx.lifecycle.R */
public final class C0041R {
    private C0041R() {
    }
}
