package androidx.lifecycle;

public interface ViewModelStoreOwner {
    ViewModelStore getViewModelStore();
}
