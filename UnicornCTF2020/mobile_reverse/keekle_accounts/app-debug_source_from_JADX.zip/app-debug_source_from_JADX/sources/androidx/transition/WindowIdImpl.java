package androidx.transition;

interface WindowIdImpl {
}
