package androidx.versionedparcelable;

/* renamed from: androidx.versionedparcelable.R */
public final class C0074R {
    private C0074R() {
    }
}
